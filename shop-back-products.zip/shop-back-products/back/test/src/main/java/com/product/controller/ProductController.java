package com.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Product;
import com.product.services.ProductService;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@RequestMapping("/api/v1/")
@OpenAPIDefinition(info= @Info(title = "Product API", version = "1.0", description= "API for managing Products"))
@Tag(name = "ProductController", description = "Product management")
public class ProductController {
	
	
	@Autowired
	ProductService productService;


	@RequestMapping(method = RequestMethod.GET, value = "products")
	@Operation(description = "get All Products")
	public ResponseEntity<List<Product>> getAllProducts() {

			List<Product> products = productService.getAllProducts();

			
			if (products.isEmpty()) {
				return ResponseEntity.noContent().build();
			}

			return  ResponseEntity.ok(products);
	}

	
	@Operation(description = "get Product by id")
	@RequestMapping(method = RequestMethod.GET, value = "products/{id}")
	public ResponseEntity<Optional<Product>> getProdcutById(@PathVariable("id") long id) {
		Optional<Product> product = productService.findProdectById(id);

		if (product.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {
			return  ResponseEntity.ok(product);
		}
	}

	
	@Operation(description = "create a product")
	@RequestMapping(method = RequestMethod.POST, value = "products")
	public ResponseEntity<Product> createProduct(@RequestBody Product product) {
		try {
			Product addproduct = productService.addProduct(product);
			return new ResponseEntity<Product>(addproduct, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<Product>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	@Operation(description = "update a Product")
	@RequestMapping(method = RequestMethod.PATCH, value = "products/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") long id, @RequestBody Product product) {
		Optional<Product> updateproduct = productService.findProdectById(id);

		if (updateproduct.isEmpty()) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		} else {			
			updateproduct.get().setCode(product.getCode());
			updateproduct.get().setName(product.getName());
			updateproduct.get().setDescription(product.getDescription());
			updateproduct.get().setPrice(product.getPrice());
			updateproduct.get().setQuantity(product.getQuantity());
			updateproduct.get().setInventoryStatus(product.getInventoryStatus());
			updateproduct.get().setCategory(product.getCategory());
			updateproduct.get().setImage(product.getImage());
			updateproduct.get().setRating(product.getRating());
			productService.addProduct(updateproduct.get());
			return ResponseEntity.ok(updateproduct.get());
		}
	}
	
	
	@Operation(description = "remove a Product")
	@RequestMapping(method = RequestMethod.DELETE, value = "products/{id}")
	public ResponseEntity<HttpStatus> deleteProduct(@PathVariable("id") long id) {
		try {
			productService.delete(id);
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<HttpStatus>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
